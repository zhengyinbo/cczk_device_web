<template>
  <div class="login-wrapper">
    <login-header />

    <div class="login-container">
      <div class="title-container">
        <h1 class="title margin-no">登录到</h1>
        <h1 class="title">长诚中科设备管理后台</h1>
      </div>

      <login v-if="type === 'login'" />
      <tdesign-setting />
    </div>

    <footer class="copyright">Copyright @ 2025-2026 CCZK. All Rights Reserved</footer>
  </div>
</template>
<script>
import Login from './components/components-login.vue';
import LoginHeader from './components/components-header.vue';
import TdesignSetting from '@/layouts/setting.vue';

export default {
  name: 'LoginIndex',
  components: {
    LoginHeader,
    Login,
    TdesignSetting,
  },
  data() {
    return {
      type: 'login',
    };
  },
  methods: {
    switchType(val) {
      this.type = val;
    },
  },
};
</script>
<style lang="less">
@import url('./index.less');
</style>
